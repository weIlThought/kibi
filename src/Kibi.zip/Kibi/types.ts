export type TypesGroupedByDamageMultiplier = Map<number, string[]>;
