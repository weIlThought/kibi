export class Logger {
  static readonly MESSAGE_PREFIX = "[Kibi]";

  static debug(...args: any[]) {
    console.debug(Logger.MESSAGE_PREFIX, ...args);
  }

  static log(...args: any[]) {
    console.log(Logger.MESSAGE_PREFIX, ...args);
  }
}
